package arrays;

public class Age {
	public static void main(String[] args) {
		   int[] age = {12, 4, 5};
		   System.out.println("Using for Loop:");
		   for(int i = 0; i < age.length; i++) {
		     System.out.println(age[i]);
		   }
		 }

}
