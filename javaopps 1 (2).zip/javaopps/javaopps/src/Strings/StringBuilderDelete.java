package Strings;

public class StringBuilderDelete {
	public static void main(String args[]){  
		StringBuilder sb=new StringBuilder("Ganga");  
		sb.delete(1,3);  
		System.out.println(sb);  
		}  
}
